let rec y lst accumulator =
    match lst with
    | [] -> accumulator
    | x::xs -> y xs (accumulator * x)
let numbers = [2; 3; 4]
let result = y numbers 1
printfn "1:Product of List: %d" result  


let rec recursion n =
    if n <= 1 then
        n
    else
        n * recursion (n - 2)
let x = recursion 11
printfn "2:Product Of odd numbers: %A" x


let Names: string list = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]
let trimmedNames: string list = List.map (fun (name: string) -> name.Trim()) Names
printfn "3:Trimmed names: %A" trimmedNames



 
let seq700 = Seq.init 700 (fun i -> i + 1)
let filteredNumbers = seq700 |> Seq.filter (fun x -> x % 7 = 0 && x % 5 = 0)
let sum = Seq.sum filteredNumbers
printfn "4:Sum of 700 numbers divisible by 7 and 5: %d" sum


let names: string list = ["James"; "Robert"; "John"; "William"; "Michael"; "David"; "Richard"]
let filteredNames = 
    List.filter (fun (name: string) -> name.Contains("i")) names
let concatenatedNames = 
    match filteredNames with
    | [] -> "" // Handle empty case
    | _ -> List.reduce (fun acc name -> acc + name) filteredNames
printfn "5:Concatenated names: %s" concatenatedNames


